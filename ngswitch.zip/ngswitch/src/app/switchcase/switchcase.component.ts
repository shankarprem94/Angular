import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-switchcase',
  templateUrl: './switchcase.component.html',
  styleUrls: ['./switchcase.component.css']
})
export class SwitchcaseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  public Product = {
    Name :'Mobile',
    Price : 10000,
    Description : 'New Model',
    MFD: new Date(),
    Image: 'assets/redmi.jpg'
  };

  public viewSection='info';

  public selectView(obj)
  {
    if(obj.target.value=='Previous')
    {
      if(this.viewSection=='summary')
        this.viewSection='info';
      else if(this.viewSection=='preview')
      this.viewSection='summary';
    }
    if(obj.target.value=='Next'){
      if(this.viewSection=='info')
        this.viewSection='summary';
      else if(this.viewSection=='summary')
        this.viewSection='preview';
    }
  }

}
