import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngclasstable',
  templateUrl: './ngclasstable.component.html',
  styleUrls: ['./ngclasstable.component.css']
})
export class NgclasstableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void { }

  public products=[{name:'Pen', price:100},{name:'Pencil', price:20},{name:'Eraser', price:10},{name:'Sharpner', price:10}];

}
