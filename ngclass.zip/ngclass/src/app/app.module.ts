import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { NgclasstableComponent } from './ngclasstable/ngclasstable.component';

@NgModule({
  declarations: [
    AppComponent,
    NgclasstableComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [NgclasstableComponent]
})
export class AppModule { }
