import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicles',
  templateUrl: './vehicles.component.html',
  styleUrls: ['./vehicles.component.css']
})
export class VehiclesComponent {
  
  vmodel: VehicleModel = new VehicleModel();
  model : VehicleListModel = new VehicleListModel();
  vehicleList : VehicleListModel = new VehicleListModel();
  
  constructor() {}
  addAudi(){
    this.vmodel={Name:'Audi', Url:'assets/audi.jpg'}
    this.model.Audi.push(this.vmodel);
   }
   
   remAudi(){
     this.model.Audi.pop();
   }
  addBMW(){
    this.vmodel={Name:'BMW', Url:'assets/bmw.jpeg'}
    this.model.BMW.push(this.vmodel);
  }

  remBMW(){
   this.model.BMW.pop();
  }
 
  addFerari(){
    this.vmodel={Name:'Ferari', Url:'assets/ferrari.jpg'}
    this.model.Ferari.push(this.vmodel);
  }

  remFerari(){
   this.model.Ferari.pop();
  }

}

class VehicleModel{
  Name : string;
  Url : string;
  // constructor(Name? : string, Url? : string){
  //   this.Name=Name;
  //   this.Url=Url;
  // }
}

class VehicleListModel{
  Ferari: Array<VehicleModel>=new Array<VehicleModel>();
  Audi: Array<VehicleModel>=new Array<VehicleModel>();
  BMW: Array<VehicleModel>=new Array<VehicleModel>();
  // constructor(Ferari? : Array<VehicleModel>, Audi? : Array<VehicleModel>, BMW? : Array<VehicleModel>){
  //   this.Ferari=Ferari;
  //   this.Audi=Audi;
  //   this.BMW=BMW;
  // }
}
