import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForevenoddComponent } from './forevenodd.component';

describe('ForevenoddComponent', () => {
  let component: ForevenoddComponent;
  let fixture: ComponentFixture<ForevenoddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForevenoddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForevenoddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
