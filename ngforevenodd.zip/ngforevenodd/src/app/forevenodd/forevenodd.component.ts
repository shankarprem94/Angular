import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forevenodd',
  templateUrl: './forevenodd.component.html',
  styleUrls: ['./forevenodd.component.css']
})
export class ForevenoddComponent {

  Products : ProductModel[] = [
                                new ProductModel('Pen', 100),
                                new ProductModel('Book', 200),
                                new ProductModel('Pencil', 50),
                                new ProductModel('Eraser', 20),
                                new ProductModel('Sharpner', 20)
                              ];

    showValue:string;

  constructor() { 
    this.showValue='';
  }

  change(ch){
    this.showValue=ch;
  }

}

class ProductModel{
  Name : string;
  Price : number;
  constructor(Name? : string, Price? : number){
    this.Name=Name;
    this.Price=Price
  }
}