import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent {
  ProductList: Array<ProductModel> = new Array<ProductModel>();
  Product: ProductModel = new ProductModel();
  ProductListStorage: any;
  constructor(){
    this.ProductList = eval(localStorage.getItem("ProductListStorage"));
  }
  saveProduct(){
    if (typeof(Storage) !== "undefined") {
      this.ProductList = eval(localStorage.getItem("ProductListStorage"));

      if( this.ProductList.length > 0){
        this.ProductList.push(this.Product);
        localStorage.removeItem("ProductListStorage");
        localStorage.setItem("ProductListStorage", JSON.stringify(this.ProductList));
        this.Product={Name:'',Price:0};
        alert("Inserted")
      }
      else{
        this.ProductList.push(this.Product);
        localStorage.setItem("ProductListStorage", JSON.stringify(this.ProductList));
        this.Product={Name:'',Price:0};
        alert("Inserted")
      }

    }
  }

  delProduct(index){
    let status = confirm("Are you sure you want to delete?");
    if(status){
      this.ProductList=eval(localStorage.getItem("ProductListStorage"));
      this.ProductList.splice(index, 1);
      localStorage.removeItem("ProductListStorage");
      localStorage.setItem("ProductListStorage", JSON.stringify(this.ProductList));
    }
  }

}

class ProductModel{
  Name : string;
  Price : number;
  constructor(Name? : string, Price? : number){
    this.Name=Name;
    this.Price=Price
  }
}