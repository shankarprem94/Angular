export class Usersdata {
    id: number;
    name: string;
    position: string;
    office: string;
    age: number;
    startDate: number;
    salary: number;

    constructor(id: number, name: string, position: string, office: string, age: number , startDate: number , salary: number) {
        this.id = id;
        this.name = name;
        this.position = position;
        this.office = office;
        this.age = age;
        this.startDate = startDate;
        this.salary = salary;

    }
}
