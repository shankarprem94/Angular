export class Employee {
    // empid:number;
    // empname:string;
    // salary:number;

    // constructor(id,name,sal){
    //     this.empid = id;
    //     this.empname= name;
    //     this.salary= sal;
    // }

    id: number;
    name: string;
    position: string;
    office: string;
    age: number;
    startDate: number;
    salary: number;

    constructor(id:number, name:any, position:any, office:any, age:any, startDate:any, salary:any) {
        this.id = id;
        this.name = name;
        this.position = position;
        this.office = office;
        this.age = age;
        this.startDate = startDate;
        this.salary = salary;

    }
}

