import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-tbl-data',
  templateUrl: './tbl-data.component.html',
  styleUrls: ['./tbl-data.component.css']
})
export class TblDataComponent implements OnInit {
  searchValue: any;
  localStorageService: any;
  constructor() { }

  ngOnInit(): void {
    this.getingData()

  }

  public gs_userID:any
  public gs_id:any
  public gs_title:any
  public gs_desciption:any


  data = [
    {
      userId: 1,
      id: 1,
      title: "sunt aut facere repellat p",
      body: "quia et suscipit suscipit recusandae consequuntur expedita "
    },
    {
      userId: 1,
      id: 2,
      title: "qui est esse",
      body: "est rerum tempore vitae sequi sint nihil reprehenderit dolor beatae ea dolores neque "
    },
    {
      userId: 1,
      id: 3,
      title: "ea molestias quasi ex",
      body: "et iusto sed quo iure voluptatem occaecati omnis eligendi aut ad "
    },
    {
      userId: 1,
      id: 4,
      title: "eum et est occaecati",
      body: "ullam et saepe reiciendis voluptatem adipisci "
    }

  ]


  public newData: any = {
    userId: '',
    id: '',
    title: '',
    body: ''
  };
  sorting() {
    alert();
    //(a, b) => (a > b ? -1 : 1)
    this.data.sort(function (a, b) {
      var nameA = a.title.toUpperCase();
      var nameB = b.title.toUpperCase();
      //return nameA == nameB ? 0 : nameA > nameB ? 1 : -1;
      if (nameA < nameB) {
        return -1;
      }
      if (nameA > nameB) {
        return 1;
      }
      return 0;
    })
  }
  item:any= [];
  search() {
    alert();
    // this.data.filter(item =>
    //   Object.keys(item).some(k => item[k] != null &&  item[k].toString().toLowerCase()
    //       .includes(this.searchValue.toLowerCase()))
    // );
  }
  AddProduct() {
    this.newData = {
      userId: this.gs_userID,
      id: this.gs_id,
      title: this.gs_title,
      body: this.gs_desciption
    }
    this.data.push(this.newData);
    // local storage 
    localStorage.setItem("localData", JSON.stringify(this.data));
   // JSON.parse(localStorage.getItem("localData"));

    alert("data added sucessfully");
    this.gs_id = '',
      this.gs_userID = '',
      this.gs_title = '',
      this.gs_desciption = ''
  }

  deleteProduct(i:number) {
    let status = confirm("Are you sure to delete?")
    if (status == true) {
      this.data.splice(i, 1);
    }

  }

  getingData() {
    var fetchLocalStorageData:any = localStorage.getItem("localData");
    //  console.log("GSDATA", JSON.parse(fetchLocalStorageData ));
    let localData = JSON.parse(fetchLocalStorageData);
    this.data = localData;
  }
}
