import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CanDeActiveRouteComponent } from './can-de-active-route/can-de-active-route.component';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ROUTE_GAURDS_ROUTE } from './route-guards-route';
import { CanActiveRouteComponent } from './can-active-route/can-active-route.component';
import { CanActiveService } from './can-active-route/can-active.service';
import { RouteGuardsComponent } from './route-guards.component';
import { LazyLodingComponent } from './lazy-loding/lazy-loding.component';



@NgModule({
  declarations: [
    RouteGuardsComponent, 
    CanActiveRouteComponent,
    CanDeActiveRouteComponent,
    LazyLodingComponent
  ],
  imports: [
    CommonModule,FormsModule,    
    RouterModule.forChild(ROUTE_GAURDS_ROUTE),
    ReactiveFormsModule

  ],
  entryComponents: [
  ],
  providers: [CanActiveService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]

})
export class RouteGuardsModule { }
