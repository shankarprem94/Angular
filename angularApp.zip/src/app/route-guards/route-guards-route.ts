import { Routes, RouterModule } from '@angular/router';
import { EmployeeDetailsComponent } from 'src/app/employee-details/employee-details.component';
import { CanActiveRouteComponent } from './can-active-route/can-active-route.component';
import { CanActiveGuard } from './can-active-route/can-active.guard';
import { CanDeActiveRouteComponent } from './can-de-active-route/can-de-active-route.component';
import { CanDeActiveGuard } from './can-de-active-route/can-de-active-route.guard';
import { LazyLodingComponent } from './lazy-loding/lazy-loding.component';
import { RouteGuardsComponent } from './route-guards.component';

export const ROUTE_GAURDS_ROUTE: Routes = [
  {
    path: 'route-gaurds', component: RouteGuardsComponent,
    children: [
    { path: '', component: LazyLodingComponent},
    { path: 'CanActiveRoute', component: CanActiveRouteComponent, canActivate: [CanActiveGuard]},
    { path: 'CanDeActiveRoute', component: CanDeActiveRouteComponent, canDeactivate:[CanDeActiveGuard]},
  
  

    ]
  }
]

