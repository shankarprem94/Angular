import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-can-active-route',
  templateUrl: './can-active-route.component.html',
  styleUrls: ['']
})
export class CanActiveRouteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
