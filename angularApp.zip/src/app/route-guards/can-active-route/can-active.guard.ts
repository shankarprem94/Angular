import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { CanActiveService } from './can-active.service';

@Injectable({
  providedIn: 'root'
})
export class CanActiveGuard implements CanActivate {
  constructor(private _canActive:CanActiveService){

  }
  canActivate():boolean {    
    if(this._canActive.isUserLoggedIn())
    return true;
    else{
      alert("permission denied for this page and i have used CanActive Route")
      return false
    }
  }
  
}
