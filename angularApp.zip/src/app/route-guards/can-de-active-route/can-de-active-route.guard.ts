import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { CanDeActiveRouteComponent } from './can-de-active-route.component';


export interface canDeactiveLeave{
  canLeave: ()=>   boolean;
}

@Injectable({
  providedIn: 'root'
})

// For this page only 

export class CanDeActiveGuard implements CanDeactivate<CanDeActiveRouteComponent> {

  canDeactivate(component: CanDeActiveRouteComponent): boolean  {

    if (component.userName.dirty) {
      return window.confirm("You have unsaved changes. Are you want to redirect/navigate, i have used Deactivate Route Guard")
    }
    return true
  }
}



// For Global

// export class CanDeActiveGuard implements CanDeactivate<canDeactiveLeave> {
//   canDeactivate(component: canDeactiveLeave)  {
//     if (component.canLeave) {
//       return component.canLeave();
//     }
//     return true
//   }
// }




