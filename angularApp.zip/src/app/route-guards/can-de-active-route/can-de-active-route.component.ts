import { Component, OnInit } from '@angular/core';
import { FormControl} from '@angular/forms'

@Component({
  selector: 'app-can-de-active-route',
  templateUrl: './can-de-active-route.component.html',
  styleUrls: ['./can-de-active-route.component.css']
})
export class CanDeActiveRouteComponent implements OnInit {

  userName:FormControl = new FormControl()
  constructor() { }

  ngOnInit(): void {
  }

}
