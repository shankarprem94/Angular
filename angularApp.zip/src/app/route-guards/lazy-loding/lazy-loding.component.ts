import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lazy-loding',
  templateUrl: './lazy-loding.component.html',
  styleUrls: ['./lazy-loding.component.css']
})
export class LazyLodingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
