import { Component } from '@angular/core';

@Component({
    selector: 'iteration-demo',
    templateUrl: 'iteration-demo.component.html',
    styleUrls:['iteration-demo.component.css']
})

export class IterationDemoComponent  {
    public product = [
        {Name:'Samsung',Price:45000},
        {Name:'Iphone',Price:53000}
    ];

    public txtName:any;
    public txtPrice:any;
    public NewProduct = {
        Name:'',
        Price:0
    };

    AddProduct(){
        this.NewProduct = {
            Name:this.txtName,
            Price: this.txtPrice
        }
        this.product.push(this.NewProduct);
        alert('Product Added');
        this.txtPrice = '';
        this.txtName = '';
    }

    DeleteProduct(index:number){
        var status = confirm('Are you sure you want to delete?');
        if(status == true){
            this.product.splice(index,1);
        }
    }
}