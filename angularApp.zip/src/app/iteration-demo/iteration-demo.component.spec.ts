import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IterationDemoComponent } from './iteration-demo.component';

describe('IterationDemoComponent', () => {
  let component: IterationDemoComponent;
  let fixture: ComponentFixture<IterationDemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IterationDemoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IterationDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
