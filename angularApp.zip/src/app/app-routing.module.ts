import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { CrudeComponent } from './crude/crude.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { RegisterComponent } from './register/register.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';


const routes: Routes = [
  {  path: '', component: LoginComponent},  
  {  path: 'landingpage',    component: LandingPageComponent},
  {  path: 'register',    component: RegisterComponent},
  {  path: 'crudoperation',    component: CrudeComponent},
  {  path: 'crudoperation/:id', component: EmployeeDetailsComponent },
  {  path: 'empDetails', component: EmployeeDetailsComponent },
  {  path: 'lazyloading', loadChildren:()=>import('./route-guards/route-guards.module').then(m=>m.RouteGuardsModule) },
 
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes),
    
  ],
  
  exports: [RouterModule]
})
export class AppRoutingModule { }
