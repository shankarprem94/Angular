import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-condition',
  templateUrl: './condition.component.html',
  styleUrls: ['./condition.component.css']
})
export class ConditionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  public products = [
    {Name:'Nike Sports',Price:5300,Category:'Shoes'},
    {Name:'Iphone',Price:54000,Category:'Electronics'}
  ];

  public filter = 'Electronics';

}
