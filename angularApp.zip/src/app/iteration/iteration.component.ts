import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-iteration',
  templateUrl: './iteration.component.html',
  styleUrls: ['./iteration.component.css']
})
export class IterationComponent implements OnInit {

  constructor() { }
  product =[
    {id:1, CarName:'Ferrai', img:'assets/img/ferrari.jpg','likes':0,'dislikes':0 },
    {id:2, CarName:'Ford', img:'assets/img/ford.jpg','likes':0,'dislikes':0 },
    {id:3, CarName:'BMW', img:'assets/img/bmw.jpg','likes':0,'dislikes':0 },
    {id:4, CarName:'Fiat',img:'assets/img/Fiat.jpg','likes':0,'dislikes':0 }
    ]
  ngOnInit(): void {
  this.getingData();
  // localStorage.setItem("gsData", JSON.stringify(this.product));
    
  }

  

  count:number= 0;
  uncount:number=0;
  fetchedObject:any ;
  localData:any;
  
  like(item:any){
    console.log("adaddasdas", item);    
    item.likes=item.likes+1;
    localStorage.setItem("gsData", JSON.stringify(this.product));
  }
  dislike(item:any){
     console.log(item);
     item.dislikes=item.dislikes+1;
     localStorage.setItem("gsData", JSON.stringify(this.product));
  }

  getingData(){
    var fetchedObject:any = localStorage.getItem("gsData");
   // console.log("GSDATA", JSON.parse(fetchedObject ));
    let localData= JSON.parse(fetchedObject );
   this.product=localData;
  }
}
