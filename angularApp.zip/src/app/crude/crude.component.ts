import { Component, OnInit } from '@angular/core';
import { EmpServiceService } from '../emp-service.service';
import { OrderPipe } from 'ngx-order-pipe';
import { Router } from '@angular/router';
@Component({
  selector: 'app-crude',
  templateUrl: './crude.component.html',
  styleUrls: ['./crude.component.css']
})
export class CrudeComponent implements OnInit {
  name: any;
  position: any;
  office: any;
  age: any;
  startDate: any;
  salary: any
  allUserData: any;
  isEdit: boolean = false;
  search: any;
  // for edit purpose
  userObj = {
    name: "",
    position: "",
    office: "",
    age: "",
    startDate: "",
    salary: ""
  }




  constructor(private empService: EmpServiceService, private _router: Router) { }

  ngOnInit(): void {
    this.getlLatestData()
  }

  //add users
  addUser(userForm: any) {
    //  console.log(userForm.value)
    let obj = userForm.value;
    //id increment
    obj.id = null;

    /*  this.servicename.methodName().subscribe(()=>{  .... })  */


    this.empService.createUser(obj).subscribe(responce => {
      //  console.log("user added sucessfully");
      userForm.form.reset();
      this.getlLatestData();
    });

  }
  //Latest Users
  getlLatestData() {
    this.empService.getLatestUsers().subscribe(responce => {
      //  console.log("Latest Data");
      this.allUserData = responce;

    });
  }


  ///Edit user
  editUser(data: any) {
    //console.log(data);
    this.isEdit = true;
    this.userObj = Object.assign({}, data);
    // console.log("dasdfasd", this.userObj);
  }
  // Update User
  updateUser(userForm: any) {
    this.empService.updateUser(this.userObj).subscribe(() => {
      this.isEdit = false;
      this.getlLatestData();
      userForm.form.reset();
    })
  }

  //Delete user
  deleteUser(data: any) {
    //  console.log(data);
    var status = confirm('Are you sure you want to delete?');
    if (status == true) {
      this.empService.deleteUser(data).subscribe(responce => {
        //   console.log("User Deleted Sucessfully");
        this.getlLatestData();

      });
    }
  }

  // search 
  SearchItems() {
    // alert()
    if (this.name == '') {
      this.ngOnInit();
    } else {
      this.allUserData = this.allUserData.filter((res: { name: string; }): any => {
        return res.name.toLocaleLowerCase().match(this.name.toLocaleLowerCase());
      })
    }
  }
  //sort
  key: any;
  reverse: boolean = false;
  sort(key: any) {
    this.key = key;
    this.reverse = !this.reverse
  }
  // trackBy
  trackById(id: number, allUserData: any): string {  
  
        return allUserData.ArtNo;  
  
      }  
    
    //view Emp Details for ActivedRouter
    ViewuserDetail(id : any){
      let url: string = "/crudoperation/" + id
           this._router.navigateByUrl(url);
        }


}
