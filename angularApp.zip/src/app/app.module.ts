import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { DirectivesComponent } from './directives/directives.component';
import { FordemoComponent } from './fordemo/fordemo.component';
import { IfdemoComponent } from './ifdemo/ifdemo.component';
import { LoginComponent } from './login/login.component';
import { TblDataComponent } from './tbl-data/tbl-data.component';
import { IterationComponent } from './iteration/iteration.component';
import { SortAndSearchComponent } from './sort-and-search/sort-and-search.component';
import { ConditionComponent } from './condition/condition.component';
import { IterationDemoComponent } from './iteration-demo/iteration-demo.component';
import { SortnSearchComponent } from './sortn-search/sortn-search.component';
import { CrudeComponent } from './crude/crude.component';
import { OrderModule } from 'ngx-order-pipe';
import { RouterModule } from '@angular/router';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { RegisterComponent } from './register/register.component';
import { HeaderComponent } from './header/header.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { AppRoutingModule } from './app-routing.module';
//import { RouteGuardsModule } from './route-guards/route-guards.module';
import { RouteGuardsModule } from './route-guards/route-guards.module';
import { CanActiveService } from './route-guards/can-active-route/can-active.service';
import { CanDeActiveGuard } from './route-guards/can-de-active-route/can-de-active-route.guard';
import { ReactiveFormsModule } from '@angular/forms';
import { LeftSidebarComponent } from './left-sidebar/left-sidebar.component';
import { landingPageModule } from './landing-page/landing-page.module';
@NgModule({
  declarations: [
    AppComponent,
    DirectivesComponent,
    LoginComponent,
    FordemoComponent,
    IfdemoComponent,
    TblDataComponent,
    IterationComponent,
    SortAndSearchComponent,
    ConditionComponent,
    IterationDemoComponent,
    SortnSearchComponent,
    CrudeComponent,
    LandingPageComponent,
    RegisterComponent,
    HeaderComponent,
    LeftSidebarComponent,
    EmployeeDetailsComponent,
  
    
  ],
  imports: [
    BrowserModule,
  // RouterModule,
    FormsModule, 
    HttpClientModule, 
    OrderModule, 
    AppRoutingModule,
    RouteGuardsModule,   //Routeer Guard Module CanActive Route Guard
    ReactiveFormsModule,
    landingPageModule
    
    
  ],
  providers: [CanActiveService, CanDeActiveGuard],
  bootstrap: [
    AppComponent
  //  DirectivesComponent
  // LoginComponent,
  //TblDataComponent
  //IterationComponent
  //SortAndSearchComponent
  // SortnSearchComponent,
  //CrudeComponent
  
  ]
})
export class AppModule { }
