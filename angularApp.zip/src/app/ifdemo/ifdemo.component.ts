import { Component } from '@angular/core';

@Component({
  selector: 'app-ifdemo',
  templateUrl: './ifdemo.component.html',
  styleUrls: ['./ifdemo.component.css']
})
export class IfdemoComponent  {
  
  isVisible:boolean = false;
  btnText:string = 'Show';
  product = {
    Name:'IPhone XS',
    Price: 3600,
    Photo: 'assets/iphone.jpg'
  } 
  
  flag:boolean = false;
  imgUrl:string = "assets/oneplus.jpg";
  imgDescription:string = "6.55 Fluid AMOLED Display with 120Hz refresh rate gives you a flagship visual experience. View Deals.";

  Display(){
    this.isVisible = (this.isVisible == false)?true:false;
    this.btnText = (this.btnText == 'Show')?'Hide':'Show';
  }


}
