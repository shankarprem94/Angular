import { Usersdata } from './usersdata';

describe('Usersdata', () => {
  it('should create an instance', () => {
   // expect(new Usersdata()).toBeTruthy();
  });
});
