import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';

@Component({
  selector: 'app-sortn-search',
  templateUrl: './sortn-search.component.html',
  styleUrls: ['./sortn-search.component.css']
})
export class SortnSearchComponent {
  originalEmployees: Employee[] = [
    new Employee(1,'Srikanth',"25000", "", "", "",""),
    new Employee(2,'Sai',34000,"", "", "",""),
    new Employee(3,'Diyansh',55000,"", "", "",""),
    new Employee(4,'Dinesh',12500, "", "", "",""),
    new Employee(5,'Raju',34500, "", "", "","")
  ];

  employees: Employee[] = [];

  constructor(){
    this.employees = this.originalEmployees;
  }

  str:string ='';
  public sortcolumn:any = 'empid';
  order = 1;

  onSearchClick(){
    this.employees = this.originalEmployees.filter((anyName)=>{
      return anyName.name.toLowerCase().indexOf(this.str.toLowerCase())>=0
    })
  }

  onSortClick(){
    this.employees = this.originalEmployees.sort((emp1:any,emp2:any)=>{
      if(this.sortcolumn == 'empid'){
        return (emp1[this.sortcolumn]-emp2[this.sortcolumn])*this.order;
      }else if(this.sortcolumn == 'empname'){
        return (emp1[this.sortcolumn].charCodeAt(0)-emp2[this.sortcolumn].charCodeAt(0))*this.order;
      }else{
        return (emp1[this.sortcolumn]-emp2[this.sortcolumn])*this.order;
      }
    })
  }
  delete(id:any){
    alert();
  }
}
