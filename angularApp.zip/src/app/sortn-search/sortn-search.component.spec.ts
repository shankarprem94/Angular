import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SortnSearchComponent } from './sortn-search.component';

describe('SortnSearchComponent', () => {
  let component: SortnSearchComponent;
  let fixture: ComponentFixture<SortnSearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SortnSearchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SortnSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
