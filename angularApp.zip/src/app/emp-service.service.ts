import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmpServiceService {

  constructor( private _http:HttpClient) { }
  createUser(dataObj:any){
   // console.log(dataObj);
    return this._http.post("http://localhost:3000/data", dataObj);
  }

  getLatestUsers(){
    return this._http.get("http://localhost:3000/data");
  }

  updateUser(dataObj:any){
    return this._http.patch("http://localhost:3000/data/"+ dataObj.id, dataObj);
  }

  deleteUser(dataObj:any){
    return this._http.delete("http://localhost:3000/data/"+ dataObj.id);
  }

  getUser(id:any){
    return this._http.get("http://localhost:3000/data/"+ id);

  }
}
