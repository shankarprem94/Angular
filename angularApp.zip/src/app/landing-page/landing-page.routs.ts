import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { LandingPageComponent } from './landing-page.component';
import { RegisterComponent } from '../register/register.component';
import { CrudeComponent } from '../crude/crude.component';
import { EmployeeDetailsComponent } from '../employee-details/employee-details.component';
import { LoginComponent } from '../login/login.component';


const routes: Routes = [
  {  path: '', component: LoginComponent},  
  {  path: 'landingpage',    component: LandingPageComponent},
  {  path: 'register',    component: RegisterComponent},
  {  path: 'crudoperation',    component: CrudeComponent},
  {  path: 'crudoperation/:id', component: EmployeeDetailsComponent },
  {  path: 'empDetails', component: EmployeeDetailsComponent },
  {  path: 'lazyloading', loadChildren:()=>import('../route-guards/route-guards.module').then(m=>m.RouteGuardsModule) }
 
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes),
    
  ],
  
  exports: [RouterModule]
})
export class LandingPageModule { }
