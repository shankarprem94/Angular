import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { CanActiveService } from '../route-guards/can-active-route/can-active.service';
import { CanDeActiveGuard } from '../route-guards/can-de-active-route/can-de-active-route.guard';

@NgModule({
  declarations: [
    
  
    
  ],
  imports: [
    BrowserModule,
  // RouterModule,
    FormsModule, 
    HttpClientModule, 
    
    
    
  ],
  providers: [CanActiveService, CanDeActiveGuard],
  
})
export class landingPageModule { }
