import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EmpServiceService } from '../emp-service.service';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {
  userData: any;

  constructor( private _router:ActivatedRoute, private empService: EmpServiceService,) { }

  ngOnInit(): void {

  // ViewDetails For ActivedRouter 
    console.log(this._router);
    console.log(this._router.snapshot.params['id']);
    let id =this._router.snapshot.params['id']; 
    this.empService.getUser(id).subscribe(data => {
    //  console.log("Latest Data");
    this.userData = data;
    console.log(this.userData.name);      

    });
  }


}
