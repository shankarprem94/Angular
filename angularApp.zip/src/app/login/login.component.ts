import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})


export class LoginComponent implements OnInit {
  public username: any;
  public password: any;
  zone: any;

 

  constructor(private _router: Router) { }

  ngOnInit() { }

  Login(){  
    //alert("function working")
    if (this.username == 'admin' && this.password == 'admin' || this.username == 'demo' && this.password == 'demo') {
      //alert("userName:  "+ this.username)     
      this._router.navigate(['/landingpage']);     
    }
    else {
      console.log(Error)
    }
  }

}