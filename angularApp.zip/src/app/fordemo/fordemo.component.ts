import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fordemo',
  templateUrl: './fordemo.component.html',
  styleUrls: ['./fordemo.component.css']
})
export class FordemoComponent  { 
  products:string[] = ["Iphone","Oneplus","Samsung","Nokia"];

  public data = [
    {
      category:'Electronics',
      products: ['Samsung','Oneplus','Iphone']
    },
    {
      category:'Shoes',
      products: ['Nike','Woodland']
    }
  ]
}
